##' get k'th Gammat matrix from path object \code{obj}. Note! If you're being
##' naive, then do whatever you want with condition.step.  # if you're using
##' stop times, condition.step should be the (stoptime + 2)
getGammat.naive = function(obj, y, condition.step=NULL){

  n = length(y)

  # Error checking
    if(length(obj$action) < condition.step ){
        stop("\n You must ask for polyhedron from less than ",
             length(obj$action), " steps! \n")
    }
    myGammat = obj$Gamma[1:obj$nk[condition.step],]
    return(list(Gammat = myGammat, condition.step=condition.step))
}

##' Produces the rows to add to Gammat matrix for IC-based stopping rule in
##' generalized lasso signal approximation problem.
getGammat.stoprule = function(obj, y, condition.step, stoprule, sigma, consec,
                              maxsteps, ebic.fac= 0.5, D, verbose=F){

  if(!(stoprule %in% c('bic','ebic','aic'))){    stop('stoprule not coded yet!') }
  
  n = length(y)
  mm = get.modelinfo(obj,y,sigma,maxsteps=maxsteps,D=D,stoprule=stoprule,ebic.fac=ebic.fac,verbose=verbose)

  ## get IC vector
  ic = mm$ic #get.ic(y,obj, sigma,maxsteps,D,type=stoprule,ebic.fac=ebic.fac)$ic

  ## s* : change in model size
  actiondirs = c(NA, sign(obj$action)[1:(maxsteps-1)])
  ## s** : change in bic
  seqdirs = c(getorder(ic))
  ## multiply s* and s**
  signs = seqdirs*actiondirs
  

  ## get stop times
  stoptime = which.rise(ic, consec, "forward") - 1
  
  if(length(seqdirs) < stoptime + consec + 1) warning(paste(stoprule, "has not stopped"))

  ## Check if conditioning steps are the same (i.e. stoptime + consec)
  stopifnot(condition.step == stoptime+consec)

  ## safely making enough empty rows to add
  rows.to.add = more.rows.to.add = matrix(NA, nrow = (stoptime+consec),
                                          ncol = ncol(obj$Gammat))
  upol = more.upol = rep(NA,stoptime+consec-1)
  states = get.states(obj$action)

  ## Add rows to |G| and |u|
  for(jj in 1:(stoptime+consec)){
  
    residual = mm$resids[,jj+1]
    const    = abs(mm$pen[jj+1] - mm$pen[jj]) #getconst(stoprule,jj,sigma,n,big.df,small.df,bic.fac,ebic.fac)   
    upol[jj] = (-signs[jj+1]) * sqrt(const)
    rows.to.add[jj,] = (-signs[jj+1]) * sign(t(residual)%*%y) * residual/sqrt(sum(residual^2))

    # Also add other direction if (1) model size change and (2) BIC comparison
#    # are *both* up or down, in direction
#    if(actiondirs[jj+1] == seqdirs[jj+1] & !any(is.na(residual))){
#      more.upol[jj] = (-signs[jj+1]) * sqrt(const)
#      more.rows.to.add[jj,] = (signs[jj+1]) * sign(t(residual)%*%y) * residual/sqrt(sum(residual^2))
#    }
  }
  
  rows.to.add = rbind(rows.to.add, 
                      more.rows.to.add)
  upol = c(upol, more.upol)

  # Get rid of non-primal-changing comparisons
  upol = upol[which(!is.na(rows.to.add[,1]))]
  rows.to.add = rows.to.add[which(!is.na(rows.to.add[,1])),]

  return(list(Gammat = rows.to.add, u = upol))
}


##' Produces the rows to add to Gammat matrix, in the regression case requires
##' X.orig, ginvX.orig and D.orig which are from the pre-elastic-net regression
##' problem
getGammat.stoprule.regression = function(obj, y, condition.step, stoprule,
                                         sigma, consec, maxsteps,  X.orig,
                                         ginvX.orig=NULL, D.orig,y0.orig){
  if(stoprule!='bic'){
    stop("Regression stopping rule only coded for BIC!")
  }

  n = length(y)
  if(is.null(ginvX.orig)) ginvX.orig = ginv(X.orig)

  # Function to get the entire sequence of information criterion values
  ic = getbic.regression(y0.orig,f0,sigma,maxsteps=maxsteps-1,
              X.orig = X.orig, ginvX.orig = ginvX.orig, D.orig = D.orig)
    

  # s* : change in model size
  actiondirs = c(NA, sign(obj$action)[1:(maxsteps-1)])
  # s** : change in bic
  seqdirs = c(getorder(ic))
  

  # multiply s* and s**
  signs = seqdirs*actiondirs

  # get stop times
  stoptime = which.rise(ic, consec, "forward") - 1
  
  if(length(seqdirs) < stoptime + consec + 1) warning(paste(stoprule, "has not stopped"))

  # Check if conditioning steps are the same (i.e. stoptime + consec)
  stopifnot(condition.step == stoptime+consec)

  # safely making enough empty rows to add
  
  rows.to.add = matrix(NA, nrow = (stoptime+consec),
                           ncol = ncol(obj$Gammat))
  upol = rep(NaN,stoptime+consec-1)

  states = get.states(f0$action)

  # Add rows to Gamma matrix and |u|)
  # First comparison is the one between the null model and the 1st dual addition
#  end.step = pmin( stoptime+consec, maxsteps)
  group.inds = lapply(1:J, function(ii){(TT*(ii-1)+1):(TT*(ii)-1) - (ii-1) })
  for(jj in 1:(stoptime+consec)){

    # Identify small and big model from which to harvest the residual 
    prev.state = states[[jj]]
    this.state = states[[jj+1]]

    big.model = (if(actiondirs[jj+1]==+1){this.state} else {prev.state})
    small.model = (if(actiondirs[jj+1]==+1){prev.state} else {this.state})    
    this.hit = big.model[!(big.model %in% small.model)] 

    this.hit = f0$action[jj+1]
    alt.breaks = big.model#unique(c(states[[jj]] , this.hit))
    null.breaks = small.model#alt.breaks[alt.breaks!=this.hit]    

    # Function to obtain the "augmented" X matrix, by breaking at the fused lasso breakpoints
    get.augmented.X = function(X,breaks,return.groups = F){
      find.which.group = function(hit) which(sapply(1:J, function(jj) hit %in% group.inds[[jj]]))
      which.group.breaks = sapply(breaks, find.which.group)
      breaks.by.group = list()
      for(groupnum in 1:J){
        thisgroup.breaks = breaks[which.group.breaks==groupnum]
        thisgroup.breaks = thisgroup.breaks - TT*(groupnum-1) + (groupnum-1)
        breaks.by.group[[groupnum]] = thisgroup.breaks
      }
      
      # Function to break var into #|breaks| variables broken at |breaks|
        brk.var = function(var,breaks){
          augmented.breaks =c(0,sort(breaks),length(var))
          all.subvecs =  sapply(1:(length(augmented.breaks)-1), 
                         function(ii){inds = (augmented.breaks[ii]+1):(augmented.breaks[ii+1])
                                      newvar = rep(0,length(var))
                                      newvar[inds] = var[inds]
                                      return(newvar)
                                     })
          return(all.subvecs)
        }
    
      X.augmented = do.call(cbind, 
                            lapply(1:length(breaks.by.group), 
                                   function(ii) brk.var(X[,ii], breaks.by.group[[ii]])))
      if(return.groups){ return(breaks.by.group) } else { return(X.augmented) }
    }

    # Augment the design matrix at their breaks
    X.aug.alt  = get.augmented.X(X.orig, alt.breaks ) 
    X.aug.null = get.augmented.X(X.orig, null.breaks)
     
    
    # projection function
    projection = function(mat){
      rm = invisible(rankMatrix(mat))
      if(rm<ncol(mat)){
        b = svd(mat)$u[,1:rm]
        return(b %*% solve(t(b)%*%b, t(b)))
      } else {
      return(mat %*% solve(t(mat)%*%mat, t(mat)))
      }
    }
    
    # Get the basis vector of the residual linear subspace
    P.alt = projection(X.aug.alt)#X.aug.alt %*% solve(t(X.aug.alt)%*% X.aug.alt, t(X.aug.alt))
    P.null = projection(X.aug.null)#X.aug.null %*% solve(t(X.aug.null)%*% X.aug.null, t(X.aug.null))
    P.diff = P.null - P.alt
    if(invisible(rankMatrix(P.diff))!=1){
      print("rank of residual projection is not 1!")
      print(alt.breaks); print(null.breaks);  print(rankMatrix(P.diff))
    }
    residual = svd(P.diff)$u[,1]

    # Get the constant
    const = (sigma^2)*(log(n))

    # Add it
    upol[jj] = (-signs[jj+1]) * sqrt(const)
    rows.to.add[jj,] = (-signs[jj+1]) * sign(t(residual)%*%y0.orig) * residual/sqrt(sum(residual^2))        
  }

  # Get rid of non-primal-changing comparisons
  upol = upol[which(!is.na(rows.to.add[,1]))]
  rows.to.add = rows.to.add[which(!is.na(rows.to.add[,1])),]

  return(list(Gammat = rows.to.add, u = upol))
}



##' Function that takes the same arguments as the getGammat.naive(), and some
##' extra arguments to extract the conditioning for the stopping rule.  Returns
##' the final Gamma matrix and u vector with stopping rules incorporated.
getGammat.with.stoprule = function(obj, y, condition.step,# usage = c("fl1d", "dualpathSvd"),
                                   stoprule, sigma, maxsteps, consec,
                                   ebic.fac= 0.5,
                                   type = c("tf","graph", "regression"), X=NULL,
                                   D=NULL, X.orig=NULL, ginvX = NULL,
                                   D.orig=NULL, y0.orig = NULL,
                                   ginvX.orig = NULL,verbose=F){
    
    ## Basic error checking
    type = match.arg(type)
    if(type=="regression" & (is.null(y0.orig)|is.null(X.orig)|is.null(D.orig))){
        stop("You need to supply y, design matrix and D matrix from pre-elastic-net regression problem!")
    }
             
    ## Get naive stuff
    G.naive = getGammat.naive(obj, y, condition.step)#, usage = c("fl1d", "dualpathSvd"))
 
    ## Get stoprule-related stuff
    if(type %in% c("tf", "graph")){
        G.new.obj = getGammat.stoprule(obj=obj, y=y,
                                       condition.step=condition.step,
                                       stoprule=stoprule, sigma=sigma,
                                       consec=consec, maxsteps=maxsteps,
                                       ebic.fac= ebic.fac, D=D, verbose=verbose)
    } else if (type == "regression"){
        G.new.obj = getGammat.stoprule.regression(obj=obj,y=y,
                                                  y0.orig = y0.orig,
                                                  condition.step = condition.step,
                                                  stoprule = "bic", sigma=sigma,
                                                  consec=consec,
                                                  maxsteps=maxsteps,
                                                  X.orig = X.orig,
                                                  D.orig = D.orig,
                                                  ginvX.orig=ginvX.orig)
    } else {
        stop(paste(type, "not coded yet."))
    }
        
    ## Combine naive rows and new rows
    G.combined = rbind(G.naive$Gammat,
                       G.new.obj$Gammat)
    uvec = c(rep(0,nrow(G.naive$Gammat)), 
             G.new.obj$u)
  
    return(list(Gammat = G.combined, u = uvec))
}




#' Helper for getdvec()
#' |breaks|: all the breakpoints from fl1d path so far
#' |k|: algorithm's step to use
#' |klater|: later step to condition on
#' |n|: length of response (= length of dvec )
makesegment  = function(breaks, k, klater, n){

if(length(breaks)<k) stop("not enough breaks!! k > number of breaks")
  K <- breaks[k] # is the index of the jump selected at step k
  
  # whether or not to condition on a later step (|klater|)
  kk <- klater

  relevantbreaks = (if(kk==1) c() else breaks[1:kk])
  endpoints = c(1,n)
  allbreaks <- c(endpoints, relevantbreaks)
  allbreaks <- sort(allbreaks)

  if(K %in% allbreaks) allbreaks = allbreaks[-which(allbreaks == K)]
  allbreaks = sort(unique(c(allbreaks, endpoints))) #temporary fix just in case the global endpoints are detected..
  min.index <- max(sum(allbreaks< K),1)             #temporary fix continued 

  Kmin <- allbreaks[min.index]
  Kmax <- allbreaks[min.index + 1]    

  if(Kmin != 1) Kmin = Kmin + 1 # special case handling
  
  return(list(Kmin=Kmin,K=K,Kmax=Kmax))
}




#' get k'th dik vector, for the segment or spike test.
getdvec = function(obj, y=NULL, k, klater = k, type =c("spike","segment","hybridsegment","general"), n){
# obj : either output from fl1d() or from dualpathSvd2()
# y     : data vector (same as the one used to produce path)
# k     : algorithm's step to use.
# klater: later step to condition on

  type <- match.arg(type)
  if(k > klater) stop("Attempting to form contrast from a later step than the conditioning step.")
  
  
# ik and sk are the index and sign of the jump selected at step k

    ik = (obj$pathobjs)$B[k]
    sk = (obj$pathobjs)$s[k] 
    breaks = (obj$pathobjs)$B
    
  if(type == "spike"){

    dik = rep(0,length(y))
    dik[ik] = -1
    dik[ik+1] = 1
    dik = sk * dik     # this ensures that the gap we're testing is positive. i.e. the jump sk(y_(ik) - y_(ik-1)) always positive!
    
  } else if (type == "segment"){

    ## extract usual segment test endpoints
    Ks = makesegment(breaks=breaks,k=k,klater=klater,n=length(y))
    K = Ks$K
    Kmin = Ks$Kmin
    Kmax = Ks$Kmax
     
    # form vector
    dik = rep(0,length(y))    
    dik[Kmin:K] <- (Kmax - K)/(Kmax - Kmin + 1)
    dik[(K+1):Kmax] <- -(K - Kmin + 1)/(Kmax - Kmin + 1)
    dik <- -sk *dik

  } else if (type == "hybridsegment"){
  ## make sure you run it to a reasonable (or full set of) steps
  
    ## extract minimum length
    sortedbreaks = sort(breaks)
    if(length(sortedbreaks)<=1){
      lens = 0
    } else {
      lens = sortedbreaks [2:length(sortedbreaks )] - sortedbreaks [1:(length(sortedbreaks )-1)]
    }
    minlen = mean(lens)*1.5 

    ## extract usual segment test endpoints
    Ks = makesegment(breaks=breaks,k=k,klater=klater,n=length(y))
    K = Ks$K
    Kmin = Ks$Kmin
    Kmax = Ks$Kmax

    ## replace Kmax and Kmin if necessary
    if( (K - Kmin) > minlen ) Kmin = ceiling(K - minlen)
    if( (Kmax - K) > minlen ) Kmax = floor(K + minlen)

    # form vector
    dik = rep(0,length(y))
    dik[Kmin:K] <- (Kmax - K)/(Kmax - Kmin + 1)
    dik[(K+1):Kmax] <- -(K - Kmin + 1)/(Kmax - Kmin + 1)
    dik <- -sk *dik
  
  } else if (type == "general") {     
    stop("Not coded yet!")  
  } else {
    stop("Not coded yet!")
  }
  return(dik)
}




#' get k'th Vup or Vlo for user-input y, G, dik and sigma
#' example usage: getGammat(fl1d(..), 1y)
getVs = function(y, G, dik, sigma, u = rep(0, nrow(G))){ 

  rho   <- G %*% dik / sum(dik^2)
  V <- (u - (G%*%y) + rho %*% (dik %*% y) ) / rho
  
  Vlo <- max(V[which(rho > 0)])
  Vup <- min(V[which(rho < 0)])
  
  Vs <- c(Vlo,Vup)
  names(Vs) <- c("Vlo","Vup")
  
  return(Vs)
}


# Old, `proprietary' version of selective one-sided test p-values
#' produce p-value for one sided test
#' |y|       : is the original noisy y
#' |dik|     : is a vector (same length as y) with -c in i_k'th entry, 
#                                                  +c in the i_k-1'th entry, 
#                                              and all else zero
#' |G|       : is the gamma vector at that step
#' |sigma|   : is the noise of the response y = Normal(theta, sigma).
#' TODO: change dik to v, without breaking everything I've ever done.
pval.fl1d <- function(y, G, dik, sigma, approx=T, threshold=T, approxtype = c("gsell","rob"), u = rep(0,nrow(G)),rhotol = 1E-10){

  approxtype <- match.arg(approxtype)

  # form rho
  rho   <- G %*% dik / sum(dik^2)
  
  # thresholding small |rho| entries to equal zero (see June 2nd meeting notes for why)
  #hist(as.numeric(rho), breaks=100)
  if(threshold)   rho[abs(rho) < rhotol] = 0  
  
  # form V and related values
  V <- (u- (G%*%y) + rho %*% (dik %*% y) ) / rho # formerly #(u- (G%*%y) + rho * (dik %*% y) ) / rho      
  suppressWarnings({
    Vlo <- max(V[which(rho > 0)]);
    Vup <- min(V[which(rho < 0)]);
    V0  <- max(V[which(rho ==0)])}
  )# a not so good way to suppress these warnings
    
    
  #cat('\n', 'Vlo, d^Ty, Vup are', '\n',Vlo,dik%*%y, Vup, '\n')
  if(Vup < dik%*%y || dik%*%y < Vlo) cat("Vlo < dik%*%y < Vhi is violated!", fill=T)
 
  denom <- (sigma * sqrt(sum(dik^2)))
  x = max(min(dik %*% y,Vup),Vlo)/denom #just in case 
  a <- Vlo/denom
  b <- Vup/denom
  TT <- (pnorm(b)-pnorm(x))/(pnorm(b)-pnorm(a))
  

# approximation by max_truncnorm() and rob_truncnorm(), both in pvals.R
  if(approx){
    if(pnorm(b) - pnorm(a) < 1E-200){
      if(approxtype == "gsell"){
#        if(b == Inf & a < 10000){ b = 10000 } else { stop("b is +Inf and a is larger than 10000 in pval calculation.")}
        TT <- max_truncnorm(x,a,b)
      } else if(approxtype == "rob"){  
        TT <- rob_truncnorm(x,a,b)
      } else {  
        TT <- 0;
      }
    }
  }

  return(TT)
}

# Makeshift replacement of all usages of pval.fl1d to poly.pval; 
# todo: change simulation code directly
pval.fl1d <- function(y, G, dik, sigma, approx=T, threshold=T, approxtype = c("gsell","rob"), u = rep(0,nrow(G))){
  return(poly.pval(y, G, u, dik, sigma, bits=NULL)$pv)
}


#' produce series of p-values for one sided test at each step k, wrapper for pval.fl1d()
#' |fl1dpath|: is from running fl1d(), and is a list that contains B, Gammat, ll, s, u
#' |sigma|   : is the noise of the response y = Normal(theta, sigma). We can choose to use the one we generated data from if we play god, or use an estimate
#'             by just taking the estimate around theta i.e. sd(y-hattheta)
#' NOTICE: this necessarily couples the hypothesis test with the jump made at that step!!
getpvals.fl1d <- function(y, fl1d.obj, sigma){
  ## get pvalues
  n = length(y)
  pvals = rep(NA,n-1)
  for(k in 1:(n-1) ){
    Gammatk = getGammat(fl1d.obj,y,k)
    dik     = getdvec(fl1d.obj,y,k)
    pvals[k] = pval.fl1d(y,Gammatk,dik,sigma)
  }
  return(pvals)
}

# 
# confint.fl1d <- function(k, fl1d.obj, sigma){
#   
#   # test code:erase
#   fl1d.obj <- fl1d_mine
#   sigma = 2 ## or estimate it, by just taking the estimate around theta i.e. sd(y-hattheta)
#   ## along the road, we may investigate what happens if theta depends on us.
#   
#   # at step "k"..
#   for(k in 1:9){
#     cat("k", k, fill=T)
#     # primalk = getprimalmat(fl1dpath$u, y ,D)[,k]
#     
#     # form d_{i_k}
#     dik = rep(0,m)
#     ik  = fl1d.obj$B[k] # is the index of the jump selected at step k
#     dik[ik] = -1
#     dik[ik+1] = 1
#     sk = fl1dpath$s[k] # is the sign of the dual variable at step k
#     dik = sk * dik     # this ensures that the gap we're testing is positive. i.e. the jump sk(y_(ik) - y_(ik-1)) always positive!
#     
#     Gammatk = getGammat(fl1dpath$Gammat,10,k)
#     
#     #form statistic TT = 1-F
#     rho   <- Gammatk %*% dik / sum(dik^2)
#     
#     whichVup = which(rho  > 0)
#     Vup_cand <- sapply(whichVup, function(j){ (- (Gammatk%*%y)[j] + rho[j] * t(dik) %*% y ) / rho[j]   })
#     Vup   <- max(Vup_cand)
#     
#     whichVlo = which(rho  < 0)
#     Vlo_cand <- sapply(whichVlo, function(j){ (- (Gammatk%*%y)[j] + rho[j] * t(dik) %*% y ) / rho[j]   })
#     Vlo   <- min(Vup_cand)
#     
#     whichV0 = which(Gammatk %*% dik == 0)
#     V0_cand <- sapply(whichV0, function(j){ (- (Gammatk%*%y)[j] + rho[j] * t(dik) %*% y ) })
#     V0   <- max(V0_cand)
#     
#     if(Vup < dik%*%y || Dik%*%y < Vlo) cat("Vlo < dik%*%y < Vhi is violated!", fill=T)
#     
#     numer <- pnorm( Vup / (sigma * sqrt(sum(dik^2)))) - pnorm( dik %*% y / (sigma * sqrt(sum(dik^2))))
#     denom <- pnorm( Vup / (sigma * sqrt(sum(dik^2)))) - pnorm( Vlo / (sigma * sqrt(sum(dik^2))))
#     
#     TT <- numer/denom
#     print(TT)
#   }
# }



makedvec = function(n,d, type = c("spike", "segment")){
  if(type=="spike"){    
    dvec <- rep(0,n)
    if(d>(n-1)){ stop("d is larger than n-1!")}
    dvec[d] <- -1
    dvec[d+1] <- 1
   } else if (type == "segment"){
    stop("Not coded yet!")    
   } else {
    stop("Not coded yet!")
   }
    return(dvec)
  }
  
  
## obtain the fraction used in calculating the pivotal statistic
  getfrac = function(Vlo, Vup, gaps){
    denom <- (sigma * sqrt(2))
    x = gaps/denom #just in case 
    a <- Vlo/denom
    b <- Vup/denom
    TT <- (pnorm(b)-pnorm(x))/(pnorm(b)-pnorm(a))
#    return(list(numer = (pnorm(b)-pnorm(x)), denom = (pnorm(b)-pnorm(a))))
    return(c(pnorm(b)-pnorm(x),pnorm(b)-pnorm(a)))
  }


# Seeing if two Gamma matrices are the same, by matching them case-by-case
# |Gamma1|, |Gamma2| are two Gamma matrices (not necessarily same number of rows)
# y0 is the original response data, just used as a reference
checksame <- function(y0,Gamma1,Gamma2,noise=1){
  y0noisy   <- y0 + rnorm(length(y0), 0, noise) 
  return(all( Gamma1 %*% y0noisy >= 0 ) == all( Gamma2 %*% y0noisy >= 0 ))
} 



##' Function to take in output form \code{dualPathSvd2()} and returns a list of
##' the states after each step in algorithm, starting with NA as the first
##' state.
get.states = function(pathobj){

    ## Extract action from pathobj
    action.obj = pathobj$action

    ## Obtain a list of actions at each step.
    actionlists = sapply(1:length(action.obj),function(ii) action.obj[1:ii] )
  
    ## Helper function to extract the final state after running through (a list of) actions
    get.final.state = function(actionlist){
        if(length(actionlist)==1) return(actionlist)
        to.delete = c()
        for(abs.coord in unique(abs(actionlist))){
            all.coord.actions = which(abs(actionlist)==abs.coord)
            if( length(all.coord.actions) > 1 ){
                if( length(all.coord.actions) %%2 ==1){
                    to.delete = c(to.delete, all.coord.actions[1:(length(all.coord.actions)-1)])
                } else {
                    to.delete = c(to.delete, all.coord.actions)
                }
            }
        }
        if(!is.null(to.delete)){
            return(actionlist[-to.delete])
        } else {
            return(actionlist)
        }
    }
    
    ## Extract them
    states = lapply(actionlists, get.final.state)
    states = c(NA,states)
    return(states)
}

##' Returns sequence of BIC of fused lasso regression model (general regressor
##' matrix X) The variable names 00.orig are to emphasize that while the f0 may
##' be from solving a ridge-penalty-added problem, what should be provided are
##' the original, non-augmented versions
getbic.regression = function(y0.orig, f0, sigma, maxsteps,X.orig, ginvX.orig, D.orig,rtol=1E-7){

  # Setup empty IC vector / problem dimensions / pseudoinverse.
#  length.bic = min(, length(f0$action))
  bic = numeric(maxsteps+1)
  TT=length(y0.orig) # largest'time'
  J = ncol(X.orig)   # number of variables in the regression
  n = length(y0.orig)
  if(is.null(ginvX.orig)) ginvX.orig = ginv(X.orig)

  # Obtain each path's state at each step
  states = get.states(f0$action)
  
  # Collect BIC at each step 0 ~ (maxsteps-1)
  for(ii in 1:(maxsteps+1)){

######### OLD WAY:  Find the basis of the row space of D_{-B}  ##################################################################3
#    current.state = states[[ii]]
#    D.interior = (if(ii==1) D else D[-current.state,])
#    proj.orth.row.space = diag(rep(1,ncol(D.interior))) - t(D.interior)%*%solve(D.interior %*% t(D.interior), D.interior)
#    tH = t(D.interior %*% ginv(X.orig)) # basis for null space of D_(-B)
#    y0.fitted = as.numeric(resid(lm(y0~tH-1)))
#    y0.fitted2 = proj.orth.row.space %*% y0

######## NEW WAY:  Find the basis of the row space of D_{-B}  ##################################################################3
    curr.state = states[[ii]]

    # Function to obtain the "augmented" X matrix, by breaking at the fused lasso breakpoints
    get.augmented.X = function(X.orig,breaks,return.groups = F){
      group.inds = lapply(1:J, function(ii){(TT*(ii-1)+1):(TT*(ii)-1) - (ii-1) })
      find.which.group = function(hit) which(sapply(1:J, function(jj) hit %in% group.inds[[jj]]))
      which.group.breaks = sapply(breaks, find.which.group)
      breaks.by.group = list()
      for(groupnum in 1:J){
        thisgroup.breaks = breaks[which.group.breaks==groupnum]
        thisgroup.breaks = thisgroup.breaks - TT*(groupnum-1) + (groupnum-1)
        breaks.by.group[[groupnum]] = thisgroup.breaks
      }
      
      # Function to break var into #|breaks| variables broken at |breaks|
      brk.var = function(var,breaks){
        augmented.breaks =c(0,sort(breaks),length(var))
        all.subvecs =  sapply(1:(length(augmented.breaks)-1), 
                       function(ii){inds = (augmented.breaks[ii]+1):(augmented.breaks[ii+1])
                                    newvar = rep(0,length(var))
                                    newvar[inds] = var[inds]
                                    return(newvar)
                                   })
        return(all.subvecs)
      }
    
      X.augmented = do.call(cbind, 
                            lapply(1:length(breaks.by.group), 
                                   function(ii) brk.var(X.orig[,ii], breaks.by.group[[ii]])))
      if(return.groups){ return(breaks.by.group) } else { return(X.augmented) }
    }

    # Augment the design matrix at their breaks
    X.aug.curr  = get.augmented.X(X.orig, curr.state ) 
    sv = svd(X.aug.curr)
    Xrank = invisible(rankMatrix(X.aug.curr))
    b = sv$u[,1:Xrank]
    # Get the basis vector of the residual linear subspace
    projection = function(mat){
      mat %*% solve(t(mat) %*% mat, t(mat)) 
    }
    Proj.curr = projection(b) #X.aug.curr %*% solve(t(X.aug.curr)%*% X.aug.curr, t(X.aug.curr))
    #y0.fitted  = Proj.curr %*% (y0.orig)
    y0.fitted = as.numeric(fitted(lm(y0.orig ~ X.aug.curr-1)))
    beta.fitted = as.numeric(coef(lm(y0.orig ~ X.aug.curr-1)))
    mygroups = get.augmented.X(X.orig,curr.state,T)


#    # sanity check
#    beta.fitted.long = rep(NA,TT*J)
#    beta.fitted.long[(1):(TT)] = beta.fitted[1]
#    beta.fitted.long[(TT+1):(TT+mygroups[[2]][1])] = beta.fitted[2]
#    beta.fitted.long[(TT+mygroups[[2]][1]+1):(2*TT)] = beta.fitted[3]
#    y0.fitted2 = X.augmented %*% beta.fitted.long
#    plot(y0.fitted,col='red');lines(y0.fitted2,col='red');points(y0,pch=16)
    
    ## Calculate bic
      RSS = sum((y0.orig - y0.fitted)^2)
      ## cat("RSS is", RSS, fill=T)
      getdf = function(D,rtol=1e-7){
          mysv = svd(diag(rep(1,ncol(D))) - projection(t(D)))
          return(sum(mysv$d>rtol))
      }
      rowind = (if(all(is.na(curr.state))) (1:nrow(D.orig)) else (1:nrow(D.orig))[-curr.state[!is.na(curr.state)]])
      df = getdf(D.orig[rowind,])#sum(sv$d > rtol)#invisible(rankMatrix(Proj.curr))
      ## cat("df is", df, fill=T)
      complexity.multiplier = sigma^2 * log(TT*J+TT) 
      complexity.penalty = df * complexity.multiplier
      ## cat("multipl is ", complexity.multiplier, fill=T)
    bic[ii] <- RSS + complexity.penalty
  }
  return(bic)
}


##' Calculates various model-related quantities for _any_ D for the signal
##' approximator case (IC, penalty, RSS, residual) \code{df.fun()} is a function that
##' returns the degrees of freedom of fit of %yhat = Proj_{null(D_B)} y%
get.modelinfo = function(f0, y0, sigma, maxsteps, D, stoprule = c('bic','ebic', 'aic'), ebic.fac=.5, verbose=F){

  stoprule = match.arg(stoprule)
  
  ## Create empty objects
  n = length(y0)  
  ic = RSS = pen = df = rep(NA,maxsteps)
  resids = matrix(NA,nrow=n,ncol=maxsteps)
  actiondirs = c(NA, sign(f0$action)[1:(maxsteps)])  # s* : change in model size

  # Obtain each path's state at each step
  states = get.states(f0$action)
  
  # Collect BIC at each step 0 ~ (maxsteps-1)
  for(ii in 1:maxsteps){
    if(verbose){
      cat('step', ii, '\n')
    }
    # Method 1: Form proj null(D_{-B}) by orth proj onto row(D_{-B}) = col(t(D_{-B})) ~= tD
      thishits = states[[ii]]
      tD = cbind(if(all(is.na(thishits))) t(D) else t(D)[,-(thishits)])
  
      proj = function(mymat){ return(mymat %*% solve(t(mymat)%*%mymat, t(mymat)))}
      rr = rankMatrix(tD)
      tDb = svd(tD)$u[,1:rr]
      curr.proj = proj(tDb)
      y0.fitted = (diag(1,n) - curr.proj) %*% y0

#      if(ii>1) {
#        prevhits = states[[ii-1]]
#        tD.prev = cbind(if(all(is.na(prevhits))) t(D) else t(D)[,-(prevhits)])
#        rr.prev = rankMatrix(tD.prev)
#        tDb.prev = svd(tD.prev)$u[,1:rr.prev]
#        prev.proj = proj(tDb.prev)
#        y0.fitted.prev = (diag(1,n) - prev.proj) %*% y0
#      }
#      
#      par(mfrow=c(2,1))
#      plot(y0.fitted,ylim = range(y0),type='o'); lines(y0.fitted.prev,col='red');
#      plot(logb(bic,base=100),ylim=c(-1,1)); abline(v=ii,col='red')

    # Method 2: Form null projection onto D_{-B} directly, from svd
#      thishits = states[[ii]]
#      D.curr = if(all(is.na(thishits))) D else D[-(thishits+1),]
#      rD.curr = rankMatrix(D.curr)
#      if(rD.curr == ncol(D.curr)){
#        null.proj = Matrix(0,nrow = length(y0),ncol = length(y0))
#      }
#      else {
#        null.curr = svd( D.curr, nv = ncol(D.curr))$v[,(rD.curr+1):ncol(D.curr)]
#        null.proj = null.curr %*% t(null.curr)
#      }
#      y0.fitted2 = null.proj %*% y0

    myRSS = sum( (y0 - y0.fitted)^2 )
    mydf  = n-rr
    if(ii==1) prev.df = mydf
    mypen = (if(stoprule=='bic'){
                 (sigma^2) * mydf * log(n) 
             } else if (stoprule=='ebic'){
                 (sigma^2) * mydf * log(n) + 2*(1-ebic.fac) *
                     log(choose(n,mydf)) * sigma^2
             } else if (stoprule=='aic'){
                 (sigma^2) * mydf * 2 
             } else {
                 stop(paste(type, "not coded yet!"))
             })
    
    # If there is an addition to the boundary set and an addition to the
    if(ii>1  & mydf != prev.df){#& actiondirs[ii] == +1
#      rankMatrix(curr.proj - prev.proj)
      ptol = 1E-10
      if(all(abs(as.numeric(curr.proj - prev.proj)) < ptol)){
        myresid = rep(NA,n)
      } else {
        myresid = svd(curr.proj - prev.proj)$u[,1]
        myresid = myresid / sqrt(sum((myresid)^2))
      }
    } else {myresid = rep(NA,n)}
    
    # Store RSS + p(df)
    RSS[ii] <- myRSS
    pen[ii] <- mypen
    ic[ii] <- myRSS + mypen
    resids[,ii] <- myresid
    df[ii] <- mydf
    
    prev.proj = curr.proj
    prev.df = mydf
  }
  
  # record things at primal-changing knots (useful for the graph case)
    ic.primal = rep(NA,maxsteps)
    ic.primal[1] = ic[1]
    df.before = 1
    for(ii in 2:length(df)){
      if(!(df.before == df[ii])){
        ic.primal[ii] = ic[ii]
      }
      df.before = df[ii]
    }
    knots.primal  = which(!is.na(ic.primal))
    resids.primal = resids[knots.primal]
    ic.primal     = ic.primal[knots.primal] 
    actiondirs.primal = actiondirs[knots.primal]

  return(list(RSS=RSS,pen=pen,ic=ic,resids=resids, 
              knots.primal = knots.primal, resids.primal = resids.primal, ic.primal = ic.primal, actiondirs.primal = actiondirs.primal))
}



## Calculates BIC for _any_ D for the signal approximator case df.fun is a
## function that returns the degrees of freedom of fit of yhat =
## Proj_{null(D_B)} y
get.ic = function(f0, y0, sigma, maxsteps, D, type = c('bic','ebic', 'aic'), ebic.fac=.5){

  # Setup empty IC vector and regressor matrix H, for k'th order trend filtering problems
  ic = RSS = pen = numeric(maxsteps+1)
  n = length(y0)  

  # Obtain each path's state at each step
  states = get.states(f0$action)
  
  # Collect BIC at each step 0 ~ (maxsteps-1)
  for(ii in 1:(maxsteps+1)){

    # Method 1: Form proj null(D_{-B}) by orth proj onto row(D_{-B}) = col(t(D_{-B})) ~= tD
      thishits = states[[ii]]
      tD = cbind(if(all(is.na(thishits))) t(D) else t(D)[,-(thishits)])
      proj = function(mymat){ return(mymat %*% solve(t(mymat)%*%mymat, t(mymat)))}
      rr = rankMatrix(tD)
      tDb = svd(tD)$u[,1:rr]
      y0.fitted = (diag(1,n) - proj(tDb)) %*% y0

    # Method 2: Form null projection onto D_{-B} directly, from svd
#      thishits = states[[ii]]
#      D.curr = if(all(is.na(thishits))) D else D[-(thishits+1),]
#      rD.curr = rankMatrix(D.curr)
#      if(rD.curr == ncol(D.curr)){
#        null.proj = Matrix(0,nrow = length(y0),ncol = length(y0))
#      }
#      else {
#        null.curr = svd( D.curr, nv = ncol(D.curr))$v[,(rD.curr+1):ncol(D.curr)]
#        null.proj = null.curr %*% t(null.curr)
#      }
#      y0.fitted2 = null.proj %*% y0

    myRSS = sum( (y0 - y0.fitted)^2 )

    mydf = n-rr
    
    if(type=='bic')  mypen = (sigma^2) * mydf * log(n)
    if(type=='ebic') mypen = (sigma^2) * mydf * log(n) + 
                              2*(1-ebic.fac) * log(choose(n,mydf)) * sigma^2
    if(type=='aic')  mypen = (sigma^2) * mydf * 2
    
    myresid = #residual from adding the latest variable to the existing variable

    # Store RSS + p(df)
    RSS[ii] <- myRSS
    pen[ii] <- mypen
    ic[ii] <- myRSS + mypen
  }
  return(list(RSS=RSS,pen=pen,ic=ic))()
}

# Returns a sequence of +1 and -1 for sequential incr and decrements in a vector
# assume first step always dips; _almost_ always true
getorder = function(bic){
  return(c(NA,sign(bic[2:(length(bic))] - bic[1:(length(bic)-1)])))
}


## Locates first point of .(consec) rises in IC path
which.rise = function(icvec, consec = 2, direction=c("forward","backward")){

  direction = match.arg(direction)
  if(direction != "forward") stop("That direction IC selection is not coded yet.")
  if(length(icvec) < consec+1) stop("Not enough steps to do forward sequential BIC/AIC!")  

  ind = 1
  done = FALSE
  while(ind < (length(icvec)-consec+1) ){
    ictol = 1E-10
    if( all(icvec[(ind+1):(ind+consec)] > icvec[(ind):(ind+consec-1)] + ictol )) break
    ind = ind+1
  }
  return(pmin(pmax(ind,1),length(icvec)))
}

##' Takes in adjacency matrix (either produced from igraph, or a matrix with
##'                            zero entries in non-adjacent edges and 1 in
##'                            adjacent edges) and produces a (sparse) D matrix
##'                            for usage in the generalized lasso
##' @import Matrix
getDmat.from.adjmat = function(adjmat, sparseMatrix=FALSE){
  n = ncol(adjmat)
  if(sparseMatrix){
    Dmat = Matrix(0,nrow=n^2,ncol=n, sparse=TRUE)
  } else {
    Dmat = matrix(0,nrow=n^2,ncol=n)
  }
  count = 1
  for(jj in 1:n){
    for(kk in jj:n){
        if(adjmat[jj,kk]==1){ # there was an error !=1
          Dmat[count,jj] = 1
          Dmat[count,kk] = -1
          count = count+1
      }
    }
  }
  Dmat = Dmat[1:(count-1),]
  return(Dmat)
}


##' Takes in a D matrix used in the generalized lasso and creates an adjacency
##' matrix (a matrix with zero entries in non-adjacent edges and 1 in adjacent
##' edges).
getadjmat.from.Dmat = function(Dmat){

  Dmat = rbind(Dmat)
  n = ncol(Dmat)
  adjmat = matrix(0,n,n)

  for(jj in 1:nrow(Dmat)){
    inds = which(Dmat[jj,]!=0)
    adjmat[inds[1],inds[2]] = 1
    adjmat[inds[2],inds[1]] = 1
  }
  return(adjmat)
}


## takes in actions from a dualpathsvd(2) object and returns the boundary set at that step
getB.from.actions = function(actions){
  B = actions
  to.delete = c()
  for(ww in 1:length(actions)){
    if(actions[ww] < 0){
      to.delete = c(to.delete, which(actions == abs(actions[ww])))
      to.delete = c(to.delete, ww)
    }
  }
  if(length(to.delete)!=0){
    B = B[-to.delete]
  }
  return(B)
}

##'  Wrapper for getmodelinfo.graph() to get bic scores only Returns BIC for
##'  steps 0~maxsteps
getbic.graph = function(f0,y0, sigma, maxsteps, Dmat, stoptime=F, dual = T){
  a = getmodelinfo.graph(f0,y0, sigma, maxsteps, Dmat, stoptime=F)
  if(dual){ return(a$bic) } else { return(a$bic.primal)}
}

##'  Function to create things related to model selection, for the graph case
##'  Input : path object, y0, initial graph, maximum steps to take, Dmat,
##'  cluster size, cluster # Output: 6 p values for each possible segment test.
getmodelinfo.graph = function(f0,y0, sigma, maxsteps, Dmat, stoptime=F){

  mygraph = graph_from_adjacency_matrix(getadjmat.from.Dmat(Dmat), mode="undirected")
  n = length(y0)  
  oldmodel = cbind(rep(1,n))
  models = list()
  df = c()
  residuals = list()
  
  # Get initial group membership + store null model
  prev.groups = list()
  for(member in unique(igraph::clusters(mygraph)$membership))  prev.groups[[member]] = which(igraph::clusters(mygraph)$membership == member)
  prev.nclust = length(prev.groups)
  models[[1]] = oldmodel
  df[1] = 1
  residuals[[1]] = NA

  for(step in 1:maxsteps){
      ## Get current Dmat
      Dmat.curr = Dmat[-getB.from.actions(f0$action[1:step]),]
      
      ## Get current Graph
      mygraph = graph_from_adjacency_matrix(getadjmat.from.Dmat(Dmat.curr), mode="undirected")
      if(nrow(rbind(Dmat.curr))==0) break
      num.connected.components = length(unique(igraph::clusters(mygraph)$membership))
      
      ## Store degrees of freedom of this step
      df[step+1] = num.connected.components
      
      ## Keep track of connected components
      curr.groups = list()
      for(member in unique(igraph::clusters(mygraph)$membership)){ 
          curr.groups[[member]] = which(igraph::clusters(mygraph)$membership == member)
      }
      curr.nclust = length(curr.groups)
      
      newbasis = rep(0,length(y0))
      
      ## If cluster was created
      if(curr.nclust == prev.nclust + 1){
          if(verbose==TRUE) { print("cluster created!") }
          matched.curr.group.ind = c()
                                        # Which cluster was created? Scan all groups from prev and curr; what has changed?
          for(jj in 1:prev.nclust){
              for(kk in 1:curr.nclust){
                  if( setequal(prev.groups[[jj]], curr.groups[[kk]])){
                      ## if _any_ of the previous groups match with current groups exactly, assign zero
                      newbasis[prev.groups[[jj]]] = 0
                      matched.curr.group.ind = c(matched.curr.group.ind, kk)
                  }
              }
          }
      }
      ## Create segment test vector
      if(curr.nclust == prev.nclust + 1){
          curr.test.group.ind = (if(length(matched.curr.group.ind) == 0) (1:curr.nclust) else (1:curr.nclust)[-matched.curr.group.ind])
          group1 = curr.groups[[curr.test.group.ind[1]]]
          group2 = curr.groups[[curr.test.group.ind[2]]]
          newbasis[group1] = 1
          
          ## Calculate residual subspace basis for the added variable
          residual = resid(lm(newbasis ~ oldmodel-1))
          oldmodel = cbind(oldmodel, newbasis)
          
          models[[step+1]] = oldmodel
          residuals[[step+1]] = residual
      } else {
          models[[step+1]] = oldmodel
          residuals[[step+1]] = NA
      }
      
      ## update groups for next iteration
      prev.groups = curr.groups
      prev.nclust = curr.nclust           
  }
  

  ## Calculate bic scores at dual knots
  bic = RSSs = complexities = rep(NA,maxsteps)
  for(ii in 1:length(df)){
    RSS = sum((resid(lm(y0 ~ models[[ii]]-1)))^2)
    complexity = log(length(y0))*(sigma^2)*df[ii]
    bic[ii] = RSS + complexity
    RSSs[ii] = RSS
    complexities[ii] = complexity
  }
  
  ## Also calculate bic at primal knots
  bic.primal = rep(NA,maxsteps+1)
  bic.primal[1] = bic[1]
  df.before = 1
  for(ii in 2:length(df)){
    if(df.before < df[ii]){
      RSS = sum((resid(lm(y0 ~ models[[ii]]-1)))^2)
#      complexity = log(df[ii])  
      mypen = log(length(y0)) * (sigma^2) * df[ii]
      bic.primal[ii] = RSS + mypen#complexity
    }
    df.before = df[ii]
  }
  knots.primal = which(!is.na(bic.primal))
  models.primal    = models[!is.na(bic.primal)] 
  residuals.primal = residuals[!is.na(bic.primal)]
  bic.primal       = bic.primal[!is.na(bic.primal)]
  
  return(list(models=models,df=df,residuals=residuals,bic=bic,
              bic.primal = bic.primal,
              knots.primal = knots.primal, 
              models.primal,residuals.primal = models.primal,residuals.primal))
}


##'  Function to run post-selection tests on graphs and store p-values results
##'  Currently only is able to do 3-clusters
##'  Input : path object, y0, initial graph, maximum steps to take, Dmat, cluster size, cluster #
##'  Output: 6 p values for each possible segment test.
sbmsim = function(f0,y0,mygraph, maxsteps,Dmat,clustersize,nclust=3,verbose=FALSE, stoptime=F){
  stopifnot(nclust==3)
  pvec = rep(NA,6)
  testtime.vec = rep(NA,6)
  
  # set initial graph's grouping
  prev.groups = list()
  for(member in unique(igraph::clusters(mygraph)$membership))  prev.groups[[member]] = which(igraph::clusters(mygraph)$membership == member)
  
  prev.nclust = length(prev.groups)

  # do clustering and conduct tests along the way (and plot them)
  for(step in 1:maxsteps){
  
    
    if(verbose){  cat(step , "out of", maxsteps, fill = TRUE) }

    # Get information about that step
      G0 = getGammat(f0, y0, step)
      Dmat.curr = Dmat[-getB.from.actions(f0$action[1:step]),]
      mygraph = graph_from_adjacency_matrix(getadjmat.from.Dmat(Dmat.curr), mode="undirected")
      if(nrow(rbind(Dmat.curr))==0) break
      

    # Keep track of connected components
      curr.groups = list()
      vsegment = rep(0,length(y0))
      
      for(member in unique(igraph::clusters(mygraph)$membership)){ 
        curr.groups[[member]] = which(igraph::clusters(mygraph)$membership == member)
      }

    curr.nclust = length(curr.groups)
    # if cluster was created
    if(curr.nclust == prev.nclust + 1){
      if(verbose==TRUE) { print("cluster created!") }
      matched.curr.group.ind = c()
      # Which cluster was created? Scan all groups from prev and curr; what has changed?
      for(jj in 1:prev.nclust){
        for(kk in 1:curr.nclust){
          if( setequal(prev.groups[[jj]], curr.groups[[kk]])){
            vsegment[prev.groups[[jj]]] = 0 # if _any_ of the previous groups match with current groups exactly, assign zero
            matched.curr.group.ind = c(matched.curr.group.ind, kk)
          }
        }
      }
      # create segment test vector
      curr.test.group.ind = (if(length(matched.curr.group.ind) == 0) (1:curr.nclust) else (1:curr.nclust)[-matched.curr.group.ind])
      group1 = curr.groups[[curr.test.group.ind[1]]]
      group2 = curr.groups[[curr.test.group.ind[2]]]
      vsegment[group1] = -1/length(group1)
      vsegment[group2] =  1/length(group2)
                
      
      # conduct segment test
      pseg = pval.fl1d(y0, G0, vsegment, sigma, approxtype="rob")

      # collect p-value only if it corresponds to one of the pairs!
      pair.list = list(list(1:clustersize, (1:clustersize)+clustersize ),
                      list((1:clustersize)+clustersize,(1:clustersize)+2*clustersize ),
                      list(1:clustersize,(1:clustersize)+2*clustersize),
                      list(1:(2*clustersize),(1:clustersize)+2*clustersize),
                      list(c(1:clustersize,(1:clustersize)+2*clustersize),(1:clustersize)+clustersize),
                      list(1:clustersize,(1+clustersize):(3*clustersize)))
      pair.list = lapply(pair.list,function(lst){ list(as.integer(lst[[1]]), as.integer(lst[[2]] ))})
                     
                      
      # record the p-value in the place where the test is defined!
      for(ll in 1:length(pair.list)){
         if( all(list(group1, group2) %in% pair.list[[ll]])){
           pvec[ll] = pseg
           testtime.vec[ll] = step
         }
      }
      
    } else if (curr.nclust +1 == prev.nclust){
      # if clusters was merged
       warning("cluster being CREATED has not been coded yet")
    } else {
      if(verbose==TRUE) { print("no cluster created!") }
    }
           
    # update groups for next iteration
    prev.groups = curr.groups
    prev.nclust = curr.nclust
    
    # break if there are enough clusters
#      if(precurr.nclust > 4){
#        cat("found enough clusters, exiting loop")
#        break
#      }
  }
  
  if(stoptime==T){
    return(list(pvec=pvec,testtime.vec=testtime.vec))
  } else {
    return(pvec)
  }
}





#  Function to run selective tests on graphs and store p-values results
#  For data from a 2d structure
#  Input : path object, y0, initial graph, maximum steps to take, Dmat, cluster size, cluster #
#  Output: 6 p values for each possible segment test.
graph2dsim = function(f0,y0,mygraph, maxsteps,Dmat,clustersize,verbose=FALSE){
  results = list()
  
  # set initial graph's grouping
  prev.groups = list()
  for(member in unique(igraph::clusters(mygraph)$membership))  prev.groups[[member]] = which(igraph::clusters(mygraph)$membership == member)
  
  prev.nclust = length(prev.groups)
  count = 1

  # do clustering and conduct tests along the way (and plot them)
  for(step in 1:maxsteps){
    if(verbose){  cat(step , "out of", maxsteps, fill = TRUE) }
    
    # Get information about that step
    G0 = getGammat(f0, y0, step)
    Dmat.curr = Dmat[-getB.from.actions(f0$action[1:step]),]
    mygraph = graph_from_adjacency_matrix(getadjmat.from.Dmat(Dmat.curr), mode="undirected")
    if(nrow(rbind(Dmat.curr))==0) break
    

    # Keep track of connected components
    curr.groups = list()
    vsegment = rep(0,length(y0))
    
    for(member in unique(igraph::clusters(mygraph)$membership)){ 
      curr.groups[[member]] = which(igraph::clusters(mygraph)$membership == member)
    }
    curr.nclust = length(curr.groups)
    
    # if cluster was created
    if(curr.nclust == prev.nclust + 1){
      if(verbose==TRUE) { print("cluster created!") }
      matched.curr.group.ind = c()
      # Which cluster was created? Scan all groups from prev and curr; what has changed?
      for(jj in 1:prev.nclust){
        for(kk in 1:curr.nclust){
          if( setequal(prev.groups[[jj]], curr.groups[[kk]])){
            vsegment[prev.groups[[jj]]] = 0 # if _any_ of the previous groups match with current groups exactly, assign zero
            matched.curr.group.ind = c(matched.curr.group.ind, kk)
          }
        }
      }
      # create segment test vector
      curr.test.group.ind = (if(length(matched.curr.group.ind) == 0) (1:curr.nclust) else (1:curr.nclust)[-matched.curr.group.ind])
      group1 = curr.groups[[curr.test.group.ind[1]]]
      group2 = curr.groups[[curr.test.group.ind[2]]]
      
      vsegment[group1] = +1/length(group1)
      vsegment[group2] =  -1/length(group2)    
      
      # adjust the sign of vsegment
      if(vsegment%*%y0 <= 0) vsegment = -vsegment 
      
      # conduct segment test
      pseg = pval.fl1d(y0, G0, vsegment, sigma, approxtype="rob")

      # record p-value and the groups that are being tested (and parse them later when aggregating results)
      results[[count]] = list(p = pseg, testttime = step, groups = list(group1=group1,
                                                          group2=group2))
      count = count + 1
      
    } else if (curr.nclust +1 == prev.nclust){
      # if clusters was merged
       warning("cluster being CREATED has not been coded yet")
    } else {
      if(verbose==TRUE) { print("no cluster created!") }
    }
           
    # update groups for next iteration
    prev.groups = curr.groups
    prev.nclust = curr.nclust
  }
  return(results)
}




# Function to show top n sized objects and their sizes
show.glutton = function(envir=.GlobalEnv, how.many = 5){
  objs=ls(envir=envir)
  obj.sizes.byte = sapply(objs,function(obj){object.size(get(obj,envir=envir))})
  obj.sizes.Mb = sapply(objs,function(obj){format(object.size(get(obj,envir=envir)),"Mb")})
  obj.sizes = head(obj.sizes.Mb[  order(obj.sizes.byte,decreasing=T)],how.many)
  print(obj.sizes)
}

# Function to show objects larger than 10 Mb in memory
see.big.objs = function(szcut=10, which.envir = c("global", "local"), verbose=F){
  which.envir = match.arg(which.envir)
  if(which.envir=="global"){
    envir = .GlobalEnv
   } else if (which.envir == "local"){
    envir = sys.frame()
   } else {
    stop("Enviroment not properly specified!")
   }
  
  large.sz = sapply(ls(envir=envir), function(objname) { sz = gsub('.{3}$', '', format(object.size(get(objname,envir=envir)),"Mb"));  if(as.numeric(sz)>szcut){return(sz)} else {return(NA)}  })
  large.sz = large.sz[!is.na(large.sz)]
  if(verbose) print(large.sz)
  return(large.sz)
}


#This function creates a color scale for use with the image()
#function. Input parameters should be consistent with those
#used in the corresponding image plot. The "axis.pos" argument
#defines the side of the axis. The "add.axis" argument defines
#whether the axis is added (default: TRUE)or not (FALSE).
## Taken from http://www.r-bloggers.com/new-version-of-image-scale-function/
image.scale <- function(z, zlim, col = heat.colors(12),
breaks, axis.pos=1, add.axis=TRUE, ...){
 if(!missing(breaks)){
  if(length(breaks) != (length(col)+1)){stop("must have one more break than colour")}
 }
 if(missing(breaks) & !missing(zlim)){
  breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1)) 
 }
 if(missing(breaks) & missing(zlim)){
  zlim <- range(z, na.rm=TRUE)
  zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)#adds a bit to the range in both directions
  zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
  breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
 }
 poly <- vector(mode="list", length(col))
 for(i in seq(poly)){
  poly[[i]] <- c(breaks[i], breaks[i+1], breaks[i+1], breaks[i])
 }
 if(axis.pos %in% c(1,3)){ylim<-c(0,1); xlim<-range(breaks)}
 if(axis.pos %in% c(2,4)){ylim<-range(breaks); xlim<-c(0,1)}
 plot(1,1,t="n",ylim=ylim, xlim=xlim, axes=FALSE, xlab="", ylab="", xaxs="i", yaxs="i", ...)  
 for(i in seq(poly)){
  if(axis.pos %in% c(1,3)){
   polygon(poly[[i]], c(0,0,1,1), col=col[i], border=NA)
  }
  if(axis.pos %in% c(2,4)){
   polygon(c(0,0,1,1), poly[[i]], col=col[i], border=NA)
  }
 }
 box()
 if(add.axis) {axis(axis.pos)}
}


# Helper function to get trend filtering contrast (for 'final model' inference)
# Takes in |pathobject$action| and test time and stop time, and returns the properly adjusted trendfiltering contrast
  get.tf.contrast = function(action, y, test.time, stop.time, order=1){
    H = getH.trendfilter(n,order)
    test.coord = f0$action[test.time] + 1
    adj.coord = c(1:(order+1), (1+states[[stop.time]]))
    adj.coord = adj.coord[adj.coord!=test.coord]
    X = H[, adj.coord]
    PH = X %*% solve(t(X) %*% X , t(X) )
    orthPH = (diag(n) - PH)
    v = as.numeric(H[,test.coord] %*% orthPH)
    if( v %*% y < 0) v = -v
    return(v)
  }

# Helper function to take all neighboring-to-each-other clusters,
# And declutter them by removing all but (rounded up) centroids
declutter = function(coords, how.close = 1, sort=T, indexonly = F){#closeby.same.direction.are.disallowed=F
  
#      coords = c(8,10,15,16,19)
#      coords=c(20,8,9,19,18)
     
  #make groups of cliques
  unsorted.coords=coords
  coords = sort(coords)      

  # error checking
  if(length(coords)<=1){
    if(length(coords)==0) cat('\n',"attempting to declutter", length(coords), "coordinates",'\n')
    return(coords)
  }  

  # get the clique memberships
  adjacent.diffs = abs(coords[1:(length(coords)-1)] - coords[2:length(coords)])

  cliq.num=1
  cliq.vec=rep(NA,length(coords))
  for(ii in 1:length(adjacent.diffs)){
    if(adjacent.diffs[ii] <= how.close){  ## used to be ==1
      cliq.vec[ii] = cliq.vec[ii+1] = cliq.num
    } else {
      cliq.num = cliq.num+1
    }
  }
  
  # determine who will leave
  leavelist = c()
  for(cliq.num in unique(cliq.vec[!is.na(cliq.vec)])){
    members = which(cliq.vec == cliq.num)
    stay = round(mean(members))
    leave = members[members!=stay]
    leavelist = c(leavelist,leave)  
  }
  if(length(leavelist)>=1){
    processed.coords = coords[-leavelist]
  } else {
    processed.coords = coords
  }
#      plot(x=coords,y=rep(1,length(coords)))
#      points(x=processed.coords,y=rep(1,length(processed.coords)),col='blue',pch=16)

  # A little safeguard for myself
  if(length(processed.coords) >= 2){
    if(any(abs(processed.coords[1:(length(processed.coords)-1)] - processed.coords[2:length(processed.coords)])==1)){ stop("decluttering is wrong")}
  }
  
  if(indexonly){
    return(which(unsorted.coords %in% processed.coords))
  } else {
    if(sort){
      return(processed.coords)
    } else {
      return(unsorted.coords[unsorted.coords %in% processed.coords])
    }
  }
}
  
  
  


### Function to make trend filtering segment contrasts
### from a regression point of view
#make.v.tf = function(test.knot, adj.knot, sign.test.knot, n, tf.order){
#  H = getH.trendfilter(n,1)
#  test.coord = test.knot+1
#  adj.coord = c(1:(tf.order+1), (1+adj.knot))
#  adj.coord = adj.coord[adj.coord!=test.coord]
#  X = H[, adj.coord ]
#  PH = fitted(lm(diag(n) ~ X -1))
#  orthPH = (diag(n) - PH)
#  v = as.numeric(H[,test.coord] %*% orthPH)
#  v = v * sign.test.knot
#  }
#  this.sign = f0$pathobj$s[f0$pathobj$B == final.model[ii]]
#  if(length(this.sign)==0){
#  f1 = dualpathSvd2(y0, D, maxsteps = stop.time-1)
#  this.sign = f1$pathobj$s[f1$pathobj$B == final.model[ii]]
#}




## Function to make trend filtering segment contrasts
## by use of null space projections
make.v.tf.fp = function(test.knot, adj.knot, test.knot.sign, D){# fp for first principles
  # B1,B2 is smaller/larger model (knot sets)
  # rr^T is pB1 - pB2, 
  # pB1 formed by by proj null(D_{-B}) by orth proj onto row(D_{-B}) = col(t(D_{-B})) ~= tD

  bigmodel = unique(c(adj.knot,test.knot)) #states[[ii]]
  smallmodel = c(adj.knot)
  smallmodel = smallmodel[smallmodel!=test.knot]
  tD = cbind(if(all(is.na(bigmodel))) t(D) else t(D)[,-(bigmodel)])
  proj = function(mymat){ return(mymat %*% solve(t(mymat)%*%mymat, t(mymat)))}

  # Big model projection
  rr = rankMatrix(tD)
  tDb = svd(tD)$u[,1:rr]
  big.proj = proj(tDb)

  # Small model projection
  tD.prev = cbind(if(all(is.na(smallmodel))) t(D) else t(D)[,-(smallmodel)])
  rr.prev = rankMatrix(tD.prev)
  tDb.prev = svd(tD.prev)$u[,1:rr.prev]
  small.proj = proj(tDb.prev)

  diff.proj = big.proj - small.proj
  myresid = svd(diff.proj)$u[,1]

  stopifnot(rankMatrix(diff.proj)==1 | as.numeric(rr.prev - rr) ==1)
  myresid = myresid / sqrt(sum((myresid)^2))
#  d1 = diff(myresid[(test.knot):(test.knot+1)])
#  d2 = diff(myresid[(test.knot+1):(test.knot+2)])
#  d2-d1
#  slopedir = d2-d1 > 0
#  slopedir = sign(slopedir-.5)

  slopedir = sign(D[test.knot,] %*% myresid)

  # This is ensuring that the direction of myresid at the test knot position (slopedir) 
  # is the same direction as the direction of slope change in the solution (test.knot.sign)
  # A conditional like # if(slopedir != sign.test.knot) .. # used to do the job
  
  myresid = test.knot.sign * slopedir  * myresid

  
  return(myresid)
}



## ' Helper function to obtain the effective design X matrix, by breaking X at
## the fused lasso regression breakpoints.
get.augmented.X = function(X,breaks,return.groups = F,TT,J,group.inds){
    find.which.group = function(hit) which(sapply(1:J, function(jj) hit %in% group.inds[[jj]]))
    which.group.breaks = sapply(breaks, find.which.group)
    breaks.by.group = list()
    for(groupnum in 1:J){
      thisgroup.breaks = breaks[which.group.breaks==groupnum]
      thisgroup.breaks = thisgroup.breaks - TT*(groupnum-1) + (groupnum-1)
      breaks.by.group[[groupnum]] = thisgroup.breaks
    }
    
    # Function to break var into #|breaks| variables broken at |breaks|
    brk.var = function(var,breaks){
      augmented.breaks =c(0,sort(breaks),length(var))
      all.subvecs =  sapply(1:(length(augmented.breaks)-1), 
                     function(ii){inds = (augmented.breaks[ii]+1):(augmented.breaks[ii+1])
                                  newvar = rep(0,length(var))
                                  newvar[inds] = var[inds]
                                  return(newvar)
                                 })
      return(all.subvecs)
    }
      
    X.augmented = do.call(cbind, 
                          lapply(1:length(breaks.by.group),
                                  function(ii) brk.var(X[,ii], breaks.by.group[[ii]])))

     if(return.groups){ return(breaks.by.group) } else { return(X.augmented) }
  
  }

## Function to produce segment test contras ONLY for the fused lasso regression example in 2016 paper 
## TT is number of time points, J is number of stocks of interest
## type = "lrt" is for the likelihood ratio formulation, and type = "direct" is for forming segment test in 
## the coefficient scale first, then moving to the response scale
make.v.regression = function(test.knot, adj.knot, test.knot.sign, f0, TT, J,
                             X.orig,X.tilde, type=c("lrt","direct")){
  type = match.arg(type) 
  group.inds = lapply(1:J, function(ii){(TT*(ii-1)+1):(TT*(ii)-1) - (ii-1) })
  alt.breaks = unique(c(adj.knot , test.knot))#states[[stop.time]]
  null.breaks = alt.breaks[alt.breaks!=test.knot]    

  # Augment the design matrix at their breaks
  X.aug.alt = get.augmented.X(X.orig, alt.breaks,F,TT,J,group.inds) 
  X.aug.null = get.augmented.X(X.orig, null.breaks,F,TT,J,group.inds)
  
  ## # Ryan's contrast  
  ## v1 = rep(0,length(alt.breaks)+J)
  ## which.test.loc = which(test.knot == sort(alt.breaks))
  ## v1[which.test.loc] = -1 
  ## v1[which.test.loc+1] = 1
  ## coefs = solve(t(X.aug.alt)%*% X.aug.alt, t(X.aug.alt))
  ## v.direct = as.numeric(v1%*%(coefs))
  ## v.direct = v.direct * test.knot.sign

  # Ryan's contrast  
  v1 = rep(0,length(alt.breaks)+J)
  which.group = get.augmented.X(X.orig, alt.breaks,T,TT,J,group.inds)
  to.add = unlist(sapply(1:length(which.group), function(jj) rep(jj, length(which.group[[jj]]))))-1
  which.test.loc = which(test.knot == sort(alt.breaks))
  which.test.loc = which.test.loc + to.add[which.test.loc]
  print(paste("column in effective design matrix is", which.test.loc)) 
  v1[which.test.loc] = -1 
  v1[which.test.loc+1] = 1
  coefs = solve(t(X.aug.alt)%*% X.aug.alt, t(X.aug.alt))
  v.direct = as.numeric(v1%*%(coefs))
  v.direct = v.direct * test.knot.sign
  
  return(v.direct)
}




## Different way of making regression segment test contrast 
make.v.regression.lrt = function(test.knot, adj.knot, test.knot.sign, f0, TT, J,
                             X.orig,X.tilde, type=c("lrt","direct")){
  type = match.arg(type) 
  group.inds = lapply(1:J, function(ii){(TT*(ii-1)+1):(TT*(ii)-1) - (ii-1) })
  alt.breaks = unique(c(adj.knot , test.knot))#states[[stop.time]]
  null.breaks = alt.breaks[alt.breaks!=test.knot]    

  # Augment the design matrix at their breaks
  X.aug.alt = get.augmented.X(X.orig, alt.breaks,F,TT,J,group.inds)
  X.aug.null = get.augmented.X(X.orig, null.breaks,F,TT,J,group.inds)
  
  # My contrast: the basis vector of the residual linear subspace
  P.alt = X.aug.alt %*% solve(t(X.aug.alt)%*% X.aug.alt, t(X.aug.alt))
  P.null = X.aug.null %*% solve(t(X.aug.null)%*% X.aug.null, t(X.aug.null))
  P.diff = P.null - P.alt
  if(rankMatrix(P.diff)!=1){
    print("rank of residual projection is not 1!")
    print(alt.breaks)
    print(null.breaks)
    print(rankMatrix(P.diff))
  } 
  my.contrast = svd(P.diff)$u[,1]

  ## Checking the signs using the immediately left/right adjacent segment means 
   translate = function(my.ind){ my.ind + floor(my.ind/(TT-1))}
   aug.breaks = sort(c(alt.breaks, (TT-1)*(0:J)))
   which.mid = which(test.knot == aug.breaks)
   which.left = which.mid - 1
   which.right = which.mid + 1
   right.inds = sapply((aug.breaks[which.mid]+1):aug.breaks[which.right], translate)
   left.inds = sapply((aug.breaks[which.left]+1):aug.breaks[which.mid], translate)
   left.mean = mean(my.contrast.coef.scale[left.inds])
   right.mean = mean(my.contrast.coef.scale[right.inds ])
   coef.scale.jump.direction = sign(right.mean-left.mean)
   my.contrast = coef.scale.jump.direction * test.knot.sign * my.contrast 

   return(my.contrast)
}

# Check correctness of polyhedron:
polyhedron.checks.out = function(y0,G,u, throw.error=F){
  all.nonneg = all((G%*%y0 >= u))
  if(all.nonneg){ 
    return(all.nonneg) 
  } else {
    if(throw.error){ 
      stop("failed Gy >= u test")
    } else { 
      print("failed Gy >= u test")
    }
    return(all.nonneg)
  }
}        

# Takes in the signs |signs| and the locations |final.model|
step.sign.plot = function(signs, final.model,n){
  signs = signs[order(final.model)]
  signs = c(-signs[1], signs)
  cumul.signs = cumsum(signs)
  final.model = sort(final.model)
  nn = length(final.model)
  indices <- vector(mode = "list", length = nn+1)
    indices[2:nn] = Map(function(a,b){a:b},
                            final.model[1:(length(final.model)-1)]+1, 
                            final.model[2:length(final.model)])
    indices[[1]] = 1:final.model[1]
    indices[[nn+1]] = (final.model[length(final.model)]+1):n
  sign0 = do.call(c, 
           lapply(1:length(cumul.signs), 
              function(ii){rep(cumul.signs[ii], length(indices[[ii]]))})
              )
  return(sign0)
}
