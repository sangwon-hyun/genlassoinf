# Returns a sequence of integers from a to b if a <= b,
# otherwise nothing. You have no idea how important this
# function is...
Seq = function(a,b) {
  if (a<=b) return(a:b)
  else return(integer(0))
}

# Returns the sign of x, with Sign(0)=1.
Sign <- function(x) {
  return(-1+2*(x>=0))
}


## A bunch of helpers
getDtfSparse = function(n,ord) {
  D = bandSparse(n, m=n, c(0,1), diagonals=list(rep(-1,n),rep(1,n-1)))
  D0 = D
  for (i in Seq(1,ord)) D = D0 %*% D
  return(D[Seq(1,n-ord-1),]) 
}

getDtf = function(n, ord) {
  return(as.matrix(fSparse(n,ord)))
}

getT = function(n,k,x=1:n) {
  T = x
  if (k==0) T = T[-1]
  else if (k%%2==1) T = T[-c(1:((k+1)/2),(n-(k-1)/2):n)]  
  else if (k%%2==0) T = T[-c(1:((k+2)/2),(n-(k-2)/2):n)]
  return(T)
}

getG = function(n,k,x=1:n) {
  T = getT(n,k,x)
  G = matrix(0,n,n)
  G[,1] = rep(1,n)
  for (j in 2:n) {
    if (j<=k+1) {
      G[,j] = x^(j-1)
    }
    else {
      G[,j] = pmax(x-T[j-k-1],0)^k
    }
  }
  return(G)
}


# Correction because getH() for trendfiltering above k>0 is actually wrong;
# This is from Ryan's trendfilter paper Lemma 2
getH.trendfilter = function(n,k,x=1:n){

  # get k'th order cumulative sum
  s = rep(1,n)
  if(k>=1){
    for(ik in 1:k)   s = cumsum(s)
  }

  # Fill in H matrix
  H = matrix(NA,nrow=n,ncol=n)
  for(i in 1:n){
    for(j in 1:n){
      if(j<=(k+1)){
        H[i,j] =  (i/n)^(j-1)
      } else {
        if(i <= j-1) {
          H[i,j] = 0
        } else {
          H[i,j] = s[i-j+1]*factorial(k)/(n^k)
        }
      }
    }
  }

  return(H)  
}


getHslow = function(n,k) {
  D = matrix(0,n,n)
  D[1,1] = 1
  for (i in 2:(k+1)) D[i,] = getDtf(n,i-2)[1,]
  D[(k+2):n,] = getDtf(n,k)
  return(round(solve(D),3))
}

getHscaled = function(n,k,x=1:n) {
  H = getH(n,k,x)
  return(H*factorial(k))
}

compare = function(a,aa,lam) {
  f = predict(a,lambda=lam)$fit
  if ("trendfilter" %in% class(aa)) ff = coef(aa,lambda=lam)$beta
  else ff = predict(aa,lambda=lam)$fit
  n = length(a$y)
  plot(1:n,a$y)
  lines(1:n,f,col="blue")
  lines(1:n,ff,col="red")
  legend("bottomleft",col=c("blue","red"),
         legend=c("LARS","TF"),lty=1)
  return(max(abs(f-ff)))
}

kspline = function(k=0, n=100, seed=0, numknots=5, knots=NULL, weights=NULL) {
  if (is.null(knots)) knots=sample(1:n,numknots)
  else numknots = length(knots)

  if (is.null(weights))
    weights=sample(c(-1,1),numknots+k+1,replace=TRUE)*rnorm(numknots+k+1,2,1)
  
  beta = rep(0,n)
  for (i in 0:k) {
    beta = beta + weights[i+1]*(1:n)^k/n^k
  }
  for (j in 1:numknots) {
    x = 1:n-knots[j]
    x = x^k*(x>0)
    beta = beta + weights[j+k+1]*x/max(x)
  }

  beta = 10*(beta-min(beta))/(max(beta)-min(beta))
  y = beta + rnorm(n,0,1)

  return(list(beta=beta,y=y))
}

pieconst = function(n=100, seed=0, numknots=5) {
  set.seed(seed)
 
  d = floor(n/numknots)
  beta = rep(sample(1:10,numknots),
    times=c(rep(d,numknots-1),n-(numknots-1)*d))
  beta = 10*(beta-min(beta))/(max(beta)-min(beta))
  
  y = beta + rnorm(n,sd=1)
  return(list(beta=beta,y=y))
}

pielin = function(n=100, seed=0) {
  set.seed(seed)
  n = 100
  knots = matrix(0,6,2)
  knots[,1] = c(1,20,45,60,85,100)
  knots[,2] = c(1,2,6,8,5,6)
  beta = rep(0,100)
  for (i in 1:(nrow(knots)-1)) {
    for (j in knots[i,1]:(knots[i+1,1])) {
      beta[j] = (knots[i+1,1]-j)/(knots[i+1,1]-knots[i,1])*knots[i,2] +
        (j-knots[i,1])/(knots[i+1,1]-knots[i,1])*knots[i+1,2]
    }
  }

  beta = 10*(beta-min(beta))/(max(beta)-min(beta))
  y = beta+rnorm(n,0,1)

  return(list(beta=beta,y=y))
}

pielinx = function(x) {
  knots = matrix(0,6,2)
  knots[,1] = c(0,20,45,60,85,100)/100
  knots[,2] = c(1,2,6,8,5,6)
  ii = max(which(x>=knots[,1]))
  if (ii==nrow(knots)) {
    return(knots[nrow(knots),2])
  }
  else {
    a = (x-knots[ii,1])/(knots[ii+1,1]-knots[ii,1])
    return(knots[ii,2]*(1-a) + knots[ii+1,2]*a)
  }
}


piequad = function(n=100, seed=0) {
  set.seed(seed)
  knots = matrix(0,4,2)
  knots[,1] = c(1,33,60,100)
  knots[,2] = c(8,6,2,4)
  beta = rep(0,n)
  endval = 0
  for (i in 1:(nrow(knots)-1)) {
    sgn = (-1)^(i+1)
    mid = (knots[i,1]+knots[i+1,1])/2
    dif = knots[i+1,1]-knots[i,1]
    
    j = knots[i,1]
    intcp = endval - (sgn*n/5*(j-mid)^2/dif^2 + (knots[i+1,1]-j)/dif*knots[i,2] +
      (j-knots[i,1])/dif*knots[i+1,2])
    
    for (j in knots[i,1]:(knots[i+1,1])) {
      beta[j] = intcp + sgn*n/5*(j-mid)^2/dif^2 + (knots[i+1,1]-j)/dif*knots[i,2] +
        (j-knots[i,1])/dif*knots[i+1,2]
    }
    endval = beta[j]
  }
  
  beta = 10*(beta-min(beta))/(max(beta)-min(beta))
  y = beta + rnorm(n,0,1)

  return(list(beta=beta,y=y))
}

piecub = function(n=100, seed=0) {
  set.seed(seed)
  n=100
  beta=rep(0,100)
  beta[1:40]=(1:40-20)^3
  beta[40:50]=-60*(40:50-50)^2 + 60*100+20^3
  beta[50:70]=-20*(50:70-50)^2 + 60*100+20^3
  beta[70:100]=-1/6*(70:100-110)^3 + -1/6*40^3 + 6000
  beta=-beta
  
  beta=10*(beta-min(beta))/(max(beta)-min(beta))
  y=beta+rnorm(n,0,1)

  return(list(beta=beta,y=y))
}

piecubx = function(x) {
  x = x*100
  if (x<=40) return((x-20)^3)
  if (x<=50) return(-60*(x-50)^2 + 60*100+20^3)
  if (x<=70) return(-30*(x-50)^2 + 60*100+20^3)
  if (x<=100) return(-1/6*(x-110)^3 + -1/6*40^3 + 6000)
}

smoothwiggly.fun = function(x) {
  f = function(a,b,c,x) return(a*(x-b)^2+c)
  fp = function(a,b,c,x) return(2*a*(x-b))

  a=-1; b=1/4; c=1;  
  if (x<=1/3) return(f(a,b,c,x))  
  aa=a; bb=b; cc=c; xx=1/3;
  a=1; b=xx-fp(aa,bb,cc,xx)/(2*a); c=f(aa,bb,cc,xx)-a*(xx-b)^2;  
  if (x<=2/3) return(f(a,b,c,x))
  aa=a; bb=b; cc=c; xx=2/3;
  b=0.7; a=fp(aa,bb,cc,xx)/(2*(xx-b)); c=f(aa,bb,cc,xx)-a*(xx-b)^2;
  if (x<=0.775) return(f(a,b,c,x))  
  aa=a; bb=b; cc=c; xx=0.775;
  b=0.8; a=fp(aa,bb,cc,xx)/(2*(xx-b)); c=f(aa,bb,cc,xx)-a*(xx-b)^2;
  if (x<=0.825) return(f(a,b,c,x))  
  aa=a; bb=b; cc=c; xx=0.825;
  b=0.85; a=fp(aa,bb,cc,xx)/(2*(xx-b)); c=f(aa,bb,cc,xx)-a*(xx-b)^2;
  if (x<=0.875) return(f(a,b,c,x))  
  aa=a; bb=b; cc=c; xx=0.875;
  b=0.9; a=fp(aa,bb,cc,xx)/(2*(xx-b)); c=f(aa,bb,cc,xx)-a*(xx-b)^2;
  if (x<=0.925) return(f(a,b,c,x))
  aa=a; bb=b; cc=c; xx=0.925;
  b=0.95; a=fp(aa,bb,cc,xx)/(2*(xx-b)); c=f(aa,bb,cc,xx)-a*(xx-b)^2;
  if (x<=0.975) return(f(a,b,c,x))
  aa=a; bb=b; cc=c; xx=0.975;
  b=1; a=fp(aa,bb,cc,xx)/(2*(xx-b)); c=f(aa,bb,cc,xx)-a*(xx-b)^2;
  return(f(a,b,c,x))
}

smoothwiggly = function(n=100, x=1:n/n) {
  u = rep(0,n)
  for (i in 1:n) u[i]=smoothwiggly.fun(x[i])
  return(u)
}

maxlam2 = function(y,k) {
  n = length(y)
  D = getDtfSparse(n,k)
  x = qr(t(D))
  u = backsolveSparse(x,y)
  return(list(u=u,maxlam=max(abs(u))))
}

## maxlam3 = function(y,k) {
##   n = length(y)
##   D = getDtfSparse(n,k)
##   x = qr(crossprod(t(D)))
##   u = backsolveSparse(x,D%*%y)
##   return(list(u=u,maxlam=max(abs(u))))
## }

backsolveSparse = function(QR, b) {
  #R = qrR(QR)
  #x = solve(R, qr.qty(QR,b)[Seq(1,nrow(R))])
  #return(as.numeric(x))
  R = qr.R(QR)
  x = solve(R, qr.qty(QR,b)[Seq(1,nrow(R))])
  if (length(QR@q)==0) return(x)
  else return(x[Order(QR@q+1)])
}

Order = function(x) {
  n = length(x)
  o = numeric(n)
  o[x] = Seq(1,n)
  return(o)
}

crit = function(y,k,lambda,beta) {
  return(0.5*sum((y-beta)^2) + lambda*sum(abs(diff(beta,differences=k+1))))
}

bx = function(x,lam) {
  y = x
  y[x>lam] = lam
  y[x< -lam] = -lam
  return(y)
}

st = function(x,s,r) {
  z = rep(0,length(x))
  z[x>s] = x[x>s]-s
  z[x< -s] = x[x< -s]+s
  # leave the first r coordinates untouched
  z[1:r] = x[1:r]
  return(z)
}

# Make sure that no two columms of A are the same
# (this works with probability one).

checkcols <- function(A) {
  b = rnorm(nrow(A))
  a = sort(t(A)%*%b)
  if (any(diff(a)==0)) return(TRUE)
  return(FALSE)
}

##' Helper functions for fl1d (by Justin)
LS = function(y, X, out = c("fitted_y", "fitted_coeff")){
  ## n-length vector y
  ## n by p matrix X  (n >= p)  
  if( out == "fitted_y" ){
    Projection <- X %*% solve( t(X) %*% X ) %*% t(X)
    yhat <- Projection %*% y
    return(yhat)
  }
  if( out == "fitted_coeff"){
    Beta_hat <- solve( t(X) %*% X ) %*% t(X)  
    return(Beta_hat)
  }
}


dual1d_Dmat = function(m){
  D = matrix(0, nrow = m-1, ncol = m)
  for(ii in 1:(m-1)){
    D[ii,ii] = -1
    D[ii,ii+1] = 1
  }
  return(D)
}

# Makes a D matrix for a matrix that is stacked as rows
graph2D_Dmat = function(m){

    m0 = sqrt(m)
    stopifnot( m0 == round(m0) )
    D = matrix(0, nrow = 2*(m0-1)*m0, ncol = m)
   
    # connect all within chunks
    for(jj in 1:m0){
      chunk = 1:m0 + (jj-1)*m0
      D[(m0-1)*(jj-1) + 1:(m0-1), chunk] = dual1d_Dmat(m0)
    }
    sofar = m0*(m0-1) 
    # connect between all adjacent chunks
    for(jj in 1:(m-m0)){
      newrow = rep(0,m)
      newrow[jj]    = -1
      newrow[jj+m0] =  1
      D[sofar+jj,] = newrow
    }
  return(D)
}

# general function that makes various D matrices
makeDmat = function(m, type = c("trend.filtering","2Dgraph"), order=0){

  type = match.arg(type)
  D = NA
  if(type == "trend.filtering"){ 
    # handles fused lasso and more
    D = dual1d_Dmat(m)
    if(order>=1){
      for(jj in 1:order){ D = dual1d_Dmat(m-jj) %*% D }
    }
    return(D)  
  } else {
    stop("Not coded yet!")
  }
}

# helper function, to make a vector input into a row matrix
asrowmat = function(obj){
  objmat = as.matrix(obj)
  if(ncol(objmat)==1 & ncol(objmat) < nrow(objmat)){
    objmat = t(objmat)
  }
  return(objmat)
}

# and likewise, column matrix
ascolmat = function(obj){
  objmat = as.matrix(obj)
  if(nrow(objmat)==1 & nrow(objmat) < ncol(objmat)){
    objmat = t(objmat)
  }
  return(objmat)
}




mod = function(num,mod){
  c = num %% mod
  if(c == 0){
    return  (mod)
  }
  else{
    return (c)
  }
}

## from github repository statsmath/genlasso/R/svdsolve.R, changing default rtol
svdsolve <- function(A,b, rtol=1e-7) {
  s = svd(A)
  di = s$d
  ii = di>rtol
  di[ii] = 1/di[ii]
  di[!ii] = 0
  return(list(x=s$v%*%(di*(t(s$u)%*%b)),q=sum(ii),s=s))
}


#' creates vector of length n whose j'th element is 1, otherwise 0. Not currently in use.
evec = function(n,j){
  v <- rep(0,n)
  v[j] <- 1
  return(v)
}

# Transform the fused lasso problem into a lasso problem, using (11) of Genlasso path paper
getlars = function(y,k,numsteps){
  n = length(y)
  H = getH(n,k)
  H1 = H[,1:(k+1)]
  H2 = H[,(k+2):n]
  Py = H1%*%solve(crossprod(H1),t(H1)%*%y0)
  yy = y0 - Py
  PH = H1%*% solve(crossprod(H1),t(H1)%*%H2) 
  HH = H2 - PH

  # extract gamma from lasso path
  out = lar(yy,HH,maxsteps=numsteps,verbose=FALSE)
  return(out)
}




#' produces primal solution from dual solution on a point in path
getprimal_from_dual = function(u, y, type = "fl1d"){
  if(type == "fl1d"){
      D = dual1d_Dmat(length(y))
  } else {
      stop("type not coded yet")
  }
  return( y - t(D)%*%u )
}

#' produces primal matrix from dual solution matrix
#' Example usage: getprimal(umat = fl1d(..)$u)
getprimalmat = function(umat, y, type="fl1d"){
  if(type == "fl1d"){
    D = dual1d_Dmat(length(y))
  } else {
    stop("type not coded yet")
  }
  bmat = apply(X = umat, MARGIN = 2, function(u){ return(getprimal(u,y, type)) })# 2 to apply over columns
  return(bmat)
}

# Make residuals from the differences in the null space projection
makeresid = function(D,prevhits,thishit,n){

      proj = function(mymat){ return(mymat %*% solve(t(mymat)%*%mymat, t(mymat)))}

      # Record t(D_{-B}) for previous and current models      
      tD.curr = t(D[,-c(prevhits,thishit)])
      tD.prev = t(D[,-prevhits])
      tDb.curr = svd(tD.curr)$u[,1:rankMatrix(tD.curr)] 
      tDb.prev = svd(tD.prev)$u[,1:rankMatrix(tD.prev)] 
      
      # form orth projections to row spaces
      p.curr = diag(1,n) - proj(tDb.curr) 
      p.prev = diag(1,n) - proj(tDb.prev)
      p.resid = (pprev - pcurr)
      
      # extract the first projection basis
      myresid = svd(p.resid)$u[,1]
      return(myresid)      
}

# Make residuals from projection, from equivalent regression problem
# prevhits and thishit should have no overlap
makeresid.tf = function(prevhits, thishit,n, k=0){
    
    # Get old model (H1) and new variable being added (H2)
    H = getH(n,k)
    nullmodel.basis.inds = 1:(k+1)
    H1 = (if(is.na(prevhits[1])) H[,nullmodel.basis.inds] else H[,c(nullmodel.basis.inds,prevhits+1)])
    H2 = H[,(thishit+ 1)]  
    
    # Obtain residual from regressing additional variable to small(old) model
    resid = resid(lm(H2 ~ H1-1)) 
     
  return(resid)
}


# Makes the residual vector from projecting a new group 
# membership onto the old ones
# |new.membership|: index set of members of a newly added group.
# |old.memberships|: matrix whose columns are partial-1-vectors containing 
#                    the existing graph cluster memberships.
# For example:
#new.membership = c(1,1,0,0,0,0)
#old.memberships = cbind(c(1,1,1,1,1,1),c(1,1,1,1,0,0))
makeresid.graph = function(new.membership, old.memberships, n){

  # make sure to check if new.index is a subset of old.index
  stopifnot(all(as.numeric(old.memberships - new.membership) %in% c(0,1)))

  # make residual vector by same argument of projecting new membership on old
  residual = resid(lm(new.membership ~ old.memberships))
  return(residual)
}


makeresid = makeresid.tf
